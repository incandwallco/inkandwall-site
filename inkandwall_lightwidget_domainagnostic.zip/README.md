# Ink & Wall Co. — Package (Domain-agnostic SEO)
Includes LightWidget IG feed, favicon/logo, sitemap (relative URLs), robots.txt, Netlify function.

## Deploy
1. Push to GitHub
2. Connect Netlify (publish directory: .)
3. Add env vars for SendGrid if using autoresponder

## Custom domain
When ready, update sitemap.xml and robots.txt with your full domain (optional).